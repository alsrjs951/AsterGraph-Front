import {
  ArrowRight,
  Check,
  FileText,
  GitPullRequest,
  Search,
} from "lucide-react";
import { Button } from "../../components/ui";
import { dossier, impact } from "../retail/model";
import { RelationMap, type WorkProps } from "./RelationMap";
import {
  approvedResult,
  candidate,
  expected,
  question,
  sourceEvent,
  sourceProduct,
  sourceStores,
} from "./workflow";

function day(iso: string) {
  const [, month, date] = iso.split("-");
  return Number(month) + "월 " + Number(date) + "일";
}
export function WorkScenes({ work: w, send }: WorkProps) {
  const revision = w.revisions.at(-1);
  const result = approvedResult(revision);
  const v = revision?.version ?? 0;
  const go = (page: "build" | "impact" | "answer") =>
    send({ type: "page", page });
  const graph = <RelationMap work={w} send={send} />;
  const build = w.page === "build";
  const review = w.page === "review";
  if (build || review) {
    const sources = [sourceProduct, sourceEvent, sourceStores];
    return (
      <article className="panel rt-card kg-card">
        <div className="kg-eyebrow">
          <span>행사 준비</span> 11월 3일 개시 · 구매운영팀
        </div>
        <h2>
          {build
            ? "내일 시작할 감귤 기획전, 예정대로 준비해도 될까요?"
            : v
              ? "감귤과 기획전의 연결을 승인했습니다"
              : "감귤의 대상 행사가 맞나요?"}
        </h2>
        <p className="kg-lead">
          {build
            ? "상품 목록에서 감귤을 찾고, 행사 계획과 배정표에서 함께 준비할 매장을 확인합니다."
            : v
              ? "검수한 행사 ID와 근거 행이 승인 이력에 함께 남습니다."
              : "점선은 아직 검수 중인 연결입니다. 행사 계획의 대상 상품을 오른쪽 원문과 대조하세요."}
        </p>
        <div className="kg-sources">
          {sources.map((s, i) => (
            <button
              key={s.source}
              aria-pressed={w.citation.source === s.source}
              onClick={() =>
                w.step < i + 1
                  ? send({ type: "extract", step: i + 1 })
                  : send({ type: "cite", citation: s })
              }
            >
              <small>
                0{i + 1} · {["상품 ID", "대상 상품", "행사 ID"][i]}
              </small>
              <b>{dossier[s.source].file}</b>
            </button>
          ))}
        </div>
        {graph}
        {build ? (
          <div className="kg-strip">
            <span>
              <b>{w.step} / 3</b> 준비 자료 연결
            </span>
            <Button
              variant="primary"
              onClick={() =>
                w.step < 3
                  ? send({ type: "extract", step: w.step + 1 })
                  : send({ type: "inspect" })
              }
            >
              {
                ["행사 계획 연결", "매장 배정 연결", "관계 검수 열기"][
                  w.step - 1
                ]
              }{" "}
              <ArrowRight size={16} />
            </Button>
          </div>
        ) : (
          <div className="kg-review">
            <span>
              <GitPullRequest size={18} /> {v ? "승인본 v1" : "관계 검수"}{" "}
              <small>행사 계획 · {expected.row}행</small>
            </span>
            {v ? (
              <>
                <strong>
                  {impact.id} → {revision!.event}
                </strong>
                <Button onClick={() => go("impact")}>
                  변경 관리 열기 <ArrowRight size={16} />
                </Button>
              </>
            ) : (
              <>
                <select
                  aria-label="대상 행사 ID"
                  value={w.candidateId}
                  disabled={!w.inspecting}
                  onChange={(e) =>
                    send({ type: "edit", value: e.target.value })
                  }
                >
                  {[candidate, expected].map((e) => (
                    <option key={e.row} value={e.cells[0]}>
                      {e.cells[0]} · {e.cells[1]}
                    </option>
                  ))}
                </select>
                {w.step < 3 ? (
                  <Button onClick={() => go("build")}>준비 자료 연결</Button>
                ) : !w.inspecting ? (
                  <Button onClick={() => send({ type: "inspect" })}>
                    원문 대조
                  </Button>
                ) : (
                  <Button
                    variant="primary"
                    disabled={w.candidateId !== expected.cells[0]}
                    onClick={() => send({ type: "approve" })}
                  >
                    <Check size={16} /> v1 승인
                  </Button>
                )}
              </>
            )}
          </div>
        )}
      </article>
    );
  }
  if (!revision || (w.page === "answer" && v < 2))
    return (
      <article className="panel rt-card kg-card">
        <div className="kg-eyebrow">승인 이력 확인</div>
        <h2>
          {v ? "변경된 납품 상태를 확인하세요" : "행사 연결을 먼저 검수하세요"}
        </h2>
        <p className="kg-lead">
          {v
            ? "납품 변경의 원문과 영향 대상을 확인하고 v2에 반영하면 답변을 조회할 수 있습니다."
            : "행사 계획과 매장 배정표를 연결한 뒤 확인한 관계를 v1으로 승인하세요."}
        </p>
        <div>
          <Button onClick={() => go(v ? "impact" : "build")}>
            {v ? "변경 관리 열기" : "행사 준비로 이동"}
          </Button>
        </div>
      </article>
    );
  if (w.page === "impact" && result) {
    const before = w.revisions[0];
    return (
      <article className="panel rt-card kg-card">
        <div className="kg-eyebrow">
          <span className="kg-urgent">공급사 공지 도착</span>{" "}
          {day(impact.latest.cells[1])} · {impact.supplier}
        </div>
        <h2>기획전 하루 전, 감귤 납품이 중단됩니다</h2>
        <p className="kg-lead">
          {dossier.notice.reason} 승인된 행사 연결을 따라 다시 확인할 업무를
          찾습니다.
        </p>
        <div className="kg-compare">
          <button onClick={() => send({ type: "compare" })}>
            <small>승인본 v1 · 기존 상태</small>
            <strong>{before.status}</strong>
          </button>
          <ArrowRight size={19} />
          <button
            onClick={() =>
              send({ type: "cite", citation: { source: "notice" } })
            }
          >
            <small>
              {v === 2 ? "변경본 v2" : "접수된 변경"} · {impact.latest.cells[1]}
            </small>
            <strong>{impact.latest.cells[2]}</strong>
          </button>
          <button className="kg-mini" onClick={() => send({ type: "compare" })}>
            변경 기록 대조 ↗
          </button>
        </div>
        {graph}
        <div className="kg-strip">
          <span>
            <b>{w.traced ? "대상 확인" : "재검토 대상"}</b> 행사 1건 · 매장{" "}
            {result.stores.length}곳
          </span>
          {v === 2 ? (
            <Button onClick={() => go("answer")}>
              승인본으로 질문 <ArrowRight size={16} />
            </Button>
          ) : !w.comparing ? (
            <Button onClick={() => send({ type: "compare" })}>
              변경 전후 대조
            </Button>
          ) : !w.traced ? (
            <Button
              onClick={() =>
                send({
                  type: "select",
                  focus: "stores",
                  citation: {
                    source: "stores",
                    rows: result.stores.map((r) => r.row),
                  },
                })
              }
            >
              참여 매장 확인
            </Button>
          ) : (
            <Button variant="primary" onClick={() => send({ type: "update" })}>
              납품 변경을 v2에 반영
            </Button>
          )}
        </div>
      </article>
    );
  }
  if (!result) return null;
  const { event, stores } = result;
  const names = stores.map((s) => s.cells[1]).join(" · ");
  return (
    <article className="panel rt-card kg-card kg-qa">
      <div className="kg-eyebrow">
        <span>구매 운영 질의</span> 승인본 v{v} · 로컬 자료 조회
      </div>
      <h2>행사 전에 어디부터 확인할까요?</h2>
      <form
        className="kg-form"
        onSubmit={(e) => {
          e.preventDefault();
          send({ type: "ask" });
        }}
      >
        <Search size={19} />
        <input
          aria-label="업무 질문"
          placeholder={question}
          value={w.query}
          onChange={(e) => send({ type: "query", value: e.target.value })}
        />
        <Button variant="primary" type="submit">
          조회
        </Button>
      </form>
      {w.answer === "found" ? (
        <>
          <section className="kg-result">
            <small>승인본 답변 · v{v}</small>
            <h3>
              {day(event.cells[3])} {event.cells[1]} · {names}
            </h3>
            <p>
              {impact.name}({revision.product})은 {event.cells[0]}의 대상
              상품입니다. 행사 기간은 {day(event.cells[3])}부터{" "}
              {day(event.cells[4])}까지이며, 배정표에는 참여 매장{" "}
              {stores.length}곳이 기록돼 있습니다.
            </p>
            <div className="kg-cites">
              <button
                onClick={() =>
                  send({
                    type: "cite",
                    citation: { source: "events", rows: [event.row] },
                  })
                }
              >
                <FileText size={15} /> 행사 계획 {event.row}행
              </button>
              <button
                aria-pressed={w.citation.source === "stores"}
                onClick={() =>
                  send({
                    type: "cite",
                    citation: {
                      source: "stores",
                      rows: stores.map((r) => r.row),
                    },
                  })
                }
              >
                <FileText size={15} /> 매장 배정표{" "}
                {stores.map((r) => r.row).join("·")}행
              </button>
            </div>
          </section>
          <div className="kg-next">
            <small>구매 담당자의 다음 업무</small>
            <strong>
              {stores.length === 2 ? "두 매장" : names}의 재고 확인 후 행사 물량
              조정 검토
            </strong>
          </div>
        </>
      ) : (
        <div className="kg-suggestion">
          <small>
            {w.answer === "unsupported"
              ? "이 시연에서 조회할 수 있는 질문"
              : "추천 질문"}
          </small>
          <button onClick={() => send({ type: "query", value: question })}>
            {question} ↗
          </button>
        </div>
      )}
    </article>
  );
}
