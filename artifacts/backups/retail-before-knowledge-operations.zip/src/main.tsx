import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import LogisticsApp from "./app/App";
import { ErrorBoundary } from "./components/ErrorBoundary";
import "./styles/tokens.css";
import "./styles/app.css";
import RetailApp from "./features/retail/RetailApp";
const App =
  new URLSearchParams(location.search).get("demo") === "logistics"
    ? LogisticsApp
    : RetailApp;
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
