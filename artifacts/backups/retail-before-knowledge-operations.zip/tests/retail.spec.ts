import { test, expect, type Page } from "@playwright/test";
import { dossier, question } from "../src/features/retail/model";
import { scenes } from "../src/features/retail/story";

test("manual retail investigation and original document references", async ({
  page,
  request,
}) => {
  await page.goto("/");
  const button = (name: string | RegExp) =>
    page.getByRole("button", { name, exact: typeof name === "string" });
  const evidence = page.getByRole("complementary", { name: "원문 근거" });
  await expect(evidence).toContainText(dossier.notice.reason);
  await button("연결 자료 확인").click();
  for (const doc of Object.values(dossier)) {
    await button(new RegExp(doc.file)).click();
    const url = await evidence.getByRole("link").getAttribute("href");
    expect(url).toBe("/retail/" + doc.file);
    const response = await request.get(url!);
    expect(response.ok()).toBe(true);
    const file = await response.body();
    if (doc.file.endsWith("csv")) expect(file.toString()).toContain("ID");
    else
      expect(file.subarray(0, 2).toString()).toBe(
        doc.file.endsWith("pdf") ? "%P" : "PK",
      );
  }
  await button("변경 내역 보기").click();
  await expect(page.locator(".rt-diff")).toContainText("납품 정상");
  await expect(page.locator(".rt-new")).toContainText("납품 중단");
  await button("그래프에서 확인").click();
  await button(/상품 · P-101/).focus();
  await page.keyboard.press("Enter");
  await expect(page.locator(".rt-graph")).toHaveClass(/rt-traced/);
  await button(/P-101 → 제철 감귤 기획전/).click();
  await expect(evidence).toContainText("행사 계획 시트 / 2행");
  await button("관련 행사 질문하기").click();
  await page.getByLabel("업무 질문").fill("다른 질문");
  await button("검색").click();
  await expect(
    page.getByRole("status").filter({ hasText: "이 시연에서는" }),
  ).toBeVisible();
  await button(/추천 질문/).click();
  await expect(page.getByLabel("업무 질문")).toHaveValue(question);
  await button("검색").click();
  await expect(page.getByLabel("조회 답변")).toContainText("E-07");
  await button("[2] 매장 행사 배정.csv").click();
  await expect(evidence).toContainText("CSV / 2·3행");
  await expect(evidence).toContainText("서면점");
  await expect(evidence).toContainText("해운대점");
  await button("검토 요약 보기").click();
  await expect(page.locator(".rt-closing")).toBeVisible();
  await button(/시연 데이터/).click();
  await expect(page.getByRole("dialog")).toContainText("로컬 자료");
});

async function snapshot(p: Page) {
  return Promise.all(
    [".rt-workspace", "h1", ".demo-caption"].map((sel) =>
      p.locator(sel).innerText(),
    ),
  );
}
for (const [width, height, theme] of [
  [1440, 900, "dark"],
  [1920, 1080, "light"],
] as const) {
  test(`retail replay matches seeks and stops at 60s · ${width}`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height });
    await page.addInitScript(
      (t) => localStorage.setItem("astergraph-theme", t),
      theme,
    );
    await page.clock.install({ time: new Date("2026-11-02T00:00:00Z") });
    await page.goto("/");
    await page.clock.pauseAt(new Date("2026-11-02T00:01:00Z"));
    await page.getByRole("button", { name: "녹화 모드", exact: true }).click();
    const expected = [];
    for (let i = 0; i < scenes.length; i++) {
      await page.keyboard.press(String(i + 1));
      await expect(page.locator(".demo-caption")).toHaveText(scenes[i].caption);
      expected.push(await snapshot(page));
    }
    await page.keyboard.press("r");
    let previous = 0;
    for (const time of [
      0, 6000, 13000, 25000, 27500, 33000, 40000, 44300, 48600, 54000, 60000,
    ]) {
      if (time > previous) await page.clock.fastForward(time - previous);
      previous = time;
      const index = scenes.findIndex((s) => s.time === time);
      if (index >= 0) expect(await snapshot(page)).toEqual(expected[index]);
      if (time === 27500)
        await expect(page.locator(".rt-node[aria-pressed=true]")).toContainText(
          "P-101",
        );
      if (time === 33000)
        await expect(page.locator(".rt-locator")).toContainText(
          "행사 계획 시트 / 2행",
        );
      if (time === 48600)
        await expect(page.locator(".rt-locator")).toContainText("2·3행");
      const overflow = await page.evaluate(() => {
        const cap = document
          .querySelector(".demo-caption")!
          .getBoundingClientRect();
        const panels = [
          ...document.querySelectorAll(
            ".rt-card,.rt-evidence,.rt-graph,.rt-node,.rt-evidence-body",
          ),
        ];
        return {
          w: document.documentElement.scrollWidth,
          h: document.documentElement.scrollHeight,
          overlap: panels.some(
            (el) => el.getBoundingClientRect().bottom > cap.top,
          ),
          clipped: panels
            .filter((el) => el.scrollHeight > el.clientHeight + 2)
            .map((el) => el.className),
        };
      });
      expect(overflow).toEqual({
        w: width,
        h: height,
        overlap: false,
        clipped: [],
      });
    }
    await expect(page.locator(".retail")).toHaveAttribute(
      "data-playing",
      "false",
    );
    await page.keyboard.press("Escape");
    await expect(page.getByTestId("timecode")).toHaveText("60.0 / 60");
    await page.getByRole("button", { name: "60초 데모 시작" }).click();
    await page.clock.fastForward(1000);
    await page.getByRole("button", { name: "일시정지", exact: true }).click();
    await page.clock.fastForward(1500);
    await expect(page.getByTestId("timecode")).toHaveText("1.0 / 60");
  });
}
