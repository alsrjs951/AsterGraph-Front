import { impact, question, type Source, type Citation } from "./model";

export const duration = 60_000;
export const scenes = [
  {
    time: 0,
    label: "공지",
    title: "공급사 공지",
    caption: "공급사의 상품 납품이 중단됐습니다. 어떤 업무가 영향을 받을까요?",
  },
  {
    time: 6000,
    label: "자료",
    title: "자료 관리",
    caption: "AsterGraph는 기업의 여러 자료를 연결된 지식으로 관리합니다.",
  },
  {
    time: 13000,
    label: "변경",
    title: "변경 관리",
    caption: "데이터 변경점을 확인하고, 관련 업무의 재검토 대상을 찾습니다.",
  },
  {
    time: 25000,
    label: "그래프",
    title: "지식그래프",
    caption:
      "상품과 연결된 행사 및 매장을 지식그래프를 통해 확인할 수 있습니다.",
  },
  {
    time: 40000,
    label: "질의",
    title: "근거 기반 질의",
    caption: "필요한 정보를 검색하고, 답변의 원본 근거까지 확인합니다.",
  },
  {
    time: 54000,
    label: "요약",
    title: "검토 요약",
    caption: "흩어진 정보를 연결하고, 변경의 영향을 근거와 함께 확인합니다.",
  },
] as const;
export type CatalogState = {
  records: boolean;
  term: string;
  source: Source | "all";
  page: number;
};
export type View = {
  catalog: CatalogState;
  ledger: boolean;
  scene: number;
  selected: string;
  citation: Citation;
  query: string;
  answer: "idle" | "found" | "unsupported";
};
export type Interaction =
  | { type: "open"; scene: number }
  | { type: "select"; selected: string; citation: Citation }
  | { type: "cite"; citation: Citation }
  | { type: "query"; value: string }
  | { type: "catalog"; patch: Partial<CatalogState> }
  | { type: "ledger"; value: boolean }
  | { type: "submit" };
function open(scene: number): View {
  const sources = [
    "notice",
    "products",
    "changes",
    "products",
    "notice",
    "events",
  ] as const;
  return {
    scene,
    catalog: { records: false, term: "", source: "all", page: 0 },
    ledger: false,
    selected: "",
    citation: { source: sources[scene] },
    query: "",
    answer: "idle",
  };
}
export function interact(view: View, action: Interaction): View {
  switch (action.type) {
    case "open":
      return open(action.scene);
    case "catalog":
      return { ...view, catalog: { ...view.catalog, ...action.patch } };
    case "ledger":
      return { ...view, ledger: action.value };
    case "select":
      return { ...view, selected: action.selected, citation: action.citation };
    case "cite":
      return { ...view, ledger: false, citation: action.citation };
    case "query":
      return {
        ...view,
        query: action.value,
        answer: "idle",
        citation: { source: "notice" },
      };
    case "submit": {
      const supported = view.query.trim() === question;
      return {
        ...view,
        answer: supported ? "found" : "unsupported",
        citation: { source: supported ? "events" : "notice" },
      };
    }
  }
}
const events: { time: number; action: Interaction }[] = [
  {
    time: 9500,
    action: { type: "catalog", patch: { records: true, term: impact.id } },
  },
  { time: 18000, action: { type: "ledger", value: true } },
  {
    time: 27500,
    action: {
      type: "select",
      selected: impact.id,
      citation: { source: "products" },
    },
  },
  ...(impact.events.length
    ? [
        {
          time: 33000,
          action: {
            type: "select" as const,
            selected: "event-edge-" + impact.events[0].cells[0],
            citation: {
              source: "events" as const,
              rows: [impact.events[0].row],
            },
          },
        },
      ]
    : []),
  { time: 42900, action: { type: "query", value: question } },
  { time: 44300, action: { type: "submit" } },
  { time: 48600, action: { type: "cite", citation: { source: "stores" } } },
];
export function viewAt(time: number, reduced = false): View {
  const scene = Math.max(
    0,
    scenes.findLastIndex((s) => time >= s.time),
  );
  let view = open(scene);
  for (const event of events) {
    if (event.time >= scenes[scene].time && event.time <= time)
      view = interact(view, event.action);
  }
  if (scene === 4 && time < 42900) {
    view = interact(view, {
      type: "query",
      value: question.slice(
        0,
        reduced
          ? question.length
          : Math.floor(((time - 40000) / 2900) * question.length),
      ),
    });
  }
  return view;
}
